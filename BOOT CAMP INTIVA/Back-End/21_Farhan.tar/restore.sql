--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tugas1;
--
-- Name: tugas1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE tugas1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE tugas1 OWNER TO postgres;

\connect tugas1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: classes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.classes (
    id_kelas character varying(2) NOT NULL,
    tingkat integer NOT NULL,
    pembeda character varying(1)
);


ALTER TABLE public.classes OWNER TO postgres;

--
-- Name: ekskul; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ekskul (
    id_ekskul integer NOT NULL,
    nama_ekskul character varying NOT NULL
);


ALTER TABLE public.ekskul OWNER TO postgres;

--
-- Name: schools; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schools (
    id_sekolah integer NOT NULL,
    nama_sekolah character varying NOT NULL
);


ALTER TABLE public.schools OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    nis integer NOT NULL,
    nama character varying NOT NULL,
    jenis_kelamin character varying NOT NULL,
    id_sekolah integer,
    id_ekskul integer,
    id_kelas character varying(2)
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.classes (id_kelas, tingkat, pembeda) FROM stdin;
\.
COPY public.classes (id_kelas, tingkat, pembeda) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: ekskul; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ekskul (id_ekskul, nama_ekskul) FROM stdin;
\.
COPY public.ekskul (id_ekskul, nama_ekskul) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: schools; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schools (id_sekolah, nama_sekolah) FROM stdin;
\.
COPY public.schools (id_sekolah, nama_sekolah) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (nis, nama, jenis_kelamin, id_sekolah, id_ekskul, id_kelas) FROM stdin;
\.
COPY public.students (nis, nama, jenis_kelamin, id_sekolah, id_ekskul, id_kelas) FROM '$$PATH$$/3340.dat';

--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id_kelas);


--
-- Name: ekskul ekskul_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ekskul
    ADD CONSTRAINT ekskul_pkey PRIMARY KEY (id_ekskul);


--
-- Name: schools schools_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schools
    ADD CONSTRAINT schools_pkey PRIMARY KEY (id_sekolah);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (nis);


--
-- Name: students ekskul_murid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT ekskul_murid FOREIGN KEY (id_ekskul) REFERENCES public.ekskul(id_ekskul);


--
-- Name: students kelas_murid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT kelas_murid FOREIGN KEY (id_kelas) REFERENCES public.classes(id_kelas);


--
-- Name: students sekolah_murid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT sekolah_murid FOREIGN KEY (id_sekolah) REFERENCES public.schools(id_sekolah);


--
-- PostgreSQL database dump complete
--

